# run.py - Main entry point for the Flask app
from app import create_app, db
from app.models import Transaction, User

app = create_app()

with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(debug=True) 