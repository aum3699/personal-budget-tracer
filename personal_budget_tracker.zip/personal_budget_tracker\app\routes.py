# app/routes.py - Blueprint and route definitions
from flask import Blueprint, render_template, redirect, url_for
from .models import Transaction
from .forms import TransactionForm
from . import db

main = Blueprint('main', __name__)

@main.route('/', methods=['GET', 'POST'])
def index():
    form = TransactionForm()
    if form.validate_on_submit():
        txn = Transaction(
            type=form.type.data,
            category=form.category.data,
            amount=form.amount.data,
            note=form.note.data
        )
        db.session.add(txn)
        db.session.commit()
        return redirect(url_for('main.index'))

    transactions = Transaction.query.order_by(Transaction.date.desc()).all()
    income = sum(t.amount for t in transactions if t.type == 'Income')
    expense = sum(t.amount for t in transactions if t.type == 'Expense')
    balance = income - expense

    return render_template('index.html', form=form, transactions=transactions,
                           income=income, expense=expense, balance=balance) 