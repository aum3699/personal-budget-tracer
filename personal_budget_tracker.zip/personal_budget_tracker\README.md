# Personal Budget Tracker

A simple web-based personal budget tracker built with Flask, SQLite, and Bootstrap.

## Features
- Add, view, and summarize incomes and expenses
- View total balance, income, and expenses
- Simple, clean Bootstrap UI

## Project Structure
```
personal_budget_tracker/
│
├── app/
│   ├── __init__.py
│   ├── routes.py
│   ├── models.py
│   ├── forms.py
│   ├── templates/
│   │   └── index.html
│   └── static/
│
├── run.py
├── requirements.txt
```

## Setup
1. **Create a virtual environment:**
   ```bash
   python -m venv venv
   venv\Scripts\activate  # On Windows
   # or
   source venv/bin/activate  # On Mac/Linux
   ```
2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
3. **Run the app:**
   ```bash
   python run.py
   ```
4. **Visit:** [http://127.0.0.1:5000](http://127.0.0.1:5000)

## Future Ideas
- Edit/delete transactions
- Export to CSV
- Monthly filtering
- User login system 