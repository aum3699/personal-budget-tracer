# app/__init__.py - Flask app factory and initialization
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'your-secret-key'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///budget.db'

    db.init_app(app)

    from .routes import main
    app.register_blueprint(main)

    return app 