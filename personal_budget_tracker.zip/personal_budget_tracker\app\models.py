# app/models.py - Database models
from . import db
from datetime import datetime

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(10))  # 'Income' or 'Expense'
    category = db.Column(db.String(50))
    amount = db.Column(db.Float)
    note = db.Column(db.String(100))
    date = db.Column(db.DateTime, default=datetime.utcnow) 